#include<stdio.h>
int main(int argc, char *argv){
char s0[12];
s0[0] = 104;
s0[1] = 101;
s0[2] = 108;
s0[3] = 108;
s0[4] = 111;
s0[5] = 32;
s0[6] = 119;
s0[7] = 111;
s0[8] = 114;
s0[9] = 108;
s0[10] = 100;
s0[11] = 0;
printf(s0);
return 0;
}
