#include <stdio.h>

int main(void){
int i;
for (i =0; i < 200; i++){
printf("%d - %c \n", i, i);
}

}
