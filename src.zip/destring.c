#include <stdio.h>
#include <stdlib.h>

/* Emit an unsigned integer as decimal digits, byte by byte */
void emitInt(int n) {
    char d[16];
    int k = 0;
    if (n == 0) {
        fputc(48, stdout);
        return;
    }
    while (n > 0) {
        d[k++] = 48 + (n % 10);
        n = n / 10;
    }
    while (k > 0) {
        k--;
        fputc(d[k], stdout);
    }
}

/* Emit the variable name: letter s followed by counter digits */
void emitVar(int counter) {
    fputc(115, stdout);
    emitInt(counter);
}

/* Emit the declarations for one captured string */
void emitDecl(char *buf, int len, int counter) {
    int i;
    /* char sN[len+1]; */
    fputc(99, stdout);
    fputc(104, stdout);
    fputc(97, stdout);
    fputc(114, stdout);
    fputc(32, stdout);
    emitVar(counter);
    fputc(91, stdout);
    emitInt(len + 1);
    fputc(93, stdout);
    fputc(59, stdout);
    fputc(10, stdout);
    /* sN[i] = byte; for each byte */
    for (i = 0; i < len; i++) {
        emitVar(counter);
        fputc(91, stdout);
        emitInt(i);
        fputc(93, stdout);
        fputc(32, stdout);
        fputc(61, stdout);
        fputc(32, stdout);
        emitInt((unsigned char)buf[i]);
        fputc(59, stdout);
        fputc(10, stdout);
    }
    /* sN[len] = 0; null terminator */
    emitVar(counter);
    fputc(91, stdout);
    emitInt(len);
    fputc(93, stdout);
    fputc(32, stdout);
    fputc(61, stdout);
    fputc(32, stdout);
    fputc(48, stdout);
    fputc(59, stdout);
    fputc(10, stdout);
}

/* Emit the variable reference (replaces the literal in the original line) */
void emitVarRef(char *modLine, int *modLen, int counter) {
    char d[16];
    int k = 0;
    int n = counter;
    modLine[*modLen] = 115;
    (*modLen)++;
    if (n == 0) {
        modLine[*modLen] = 48;
        (*modLen)++;
        return;
    }
    while (n > 0) {
        d[k++] = 48 + (n % 10);
        n = n / 10;
    }
    while (k > 0) {
        k--;
        modLine[*modLen] = d[k];
        (*modLen)++;
    }
}

/* Translate a backslash escape sequence to its byte value */
int decodeEscape(int c) {
    if (c == 110) return 10;
    if (c == 116) return 9;
    if (c == 114) return 13;
    if (c == 48)  return 0;
    if (c == 92)  return 92;
    if (c == 34)  return 34;
    if (c == 39)  return 39;
    if (c == 97)  return 7;
    if (c == 98)  return 8;
    if (c == 102) return 12;
    if (c == 118) return 11;
    return c;
}

int main(int argc, const char *argv[]) {
    FILE *f;
    char rb[3], err1[24], err2[36];
    char line[8192];
    char str[2048];
    char modLine[16384];
    int i, c, lineLen, strLen, modLen, counter;

    setbuf(stdout, NULL);

    /* err1 = error: no file provided\n */
    err1[0] = 101;
    err1[1] = 114;
    err1[2] = 114;
    err1[3] = 111;
    err1[4] = 114;
    err1[5] = 58;
    err1[6] = 32;
    err1[7] = 110;
    err1[8] = 111;
    err1[9] = 32;
    err1[10] = 102;
    err1[11] = 105;
    err1[12] = 108;
    err1[13] = 101;
    err1[14] = 32;
    err1[15] = 112;
    err1[16] = 114;
    err1[17] = 111;
    err1[18] = 118;
    err1[19] = 105;
    err1[20] = 100;
    err1[21] = 101;
    err1[22] = 100;
    err1[23] = 10;

    if (argc < 2) {
        for (i = 0; i < 24; i++) fputc(err1[i], stderr);
        return 1;
    }

    rb[0] = 114;
    rb[1] = 98;
    rb[2] = 0;
    f = fopen(argv[1], rb);
    if (f == NULL) {
        /* err2 = an error occurred while opening file\n */
        err2[0] = 97;
        err2[1] = 110;
        err2[2] = 32;
        err2[3] = 101;
        err2[4] = 114;
        err2[5] = 114;
        err2[6] = 111;
        err2[7] = 114;
        err2[8] = 32;
        err2[9] = 111;
        err2[10] = 99;
        err2[11] = 99;
        err2[12] = 117;
        err2[13] = 114;
        err2[14] = 114;
        err2[15] = 101;
        err2[16] = 100;
        err2[17] = 32;
        err2[18] = 119;
        err2[19] = 104;
        err2[20] = 105;
        err2[21] = 108;
        err2[22] = 101;
        err2[23] = 32;
        err2[24] = 111;
        err2[25] = 112;
        err2[26] = 101;
        err2[27] = 110;
        err2[28] = 105;
        err2[29] = 110;
        err2[30] = 103;
        err2[31] = 32;
        err2[32] = 102;
        err2[33] = 105;
        err2[34] = 108;
        err2[35] = 101;
        for (i = 0; i < 36; i++) fputc(err2[i], stderr);
        fputc(10, stderr);
        return 1;
    }

    counter = 0;
    lineLen = 0;

    while ((c = fgetc(f)) != EOF) {
        if (c == 10) {
            /* End of line: process the buffered line */
            modLen = 0;
            i = 0;
            while (i < lineLen) {
                if (line[i] == 34) {
                    /* Found opening quote: capture string content */
                    strLen = 0;
                    i++;
                    while (i < lineLen && line[i] != 34) {
                        if (line[i] == 92 && i + 1 < lineLen) {
                            i++;
                            if (strLen < 2048) {
                                str[strLen] = decodeEscape((unsigned char)line[i]);
                                strLen++;
                            }
                            i++;
                        } else {
                            if (strLen < 2048) {
                                str[strLen] = line[i];
                                strLen++;
                            }
                            i++;
                        }
                    }
                    if (i < lineLen) i++; /* skip closing quote */

                    /* Emit declarations BEFORE the modified line */
                    emitDecl(str, strLen, counter);
                    /* Insert variable reference into the modified line */
                    emitVarRef(modLine, &modLen, counter);
                    counter++;
                } else {
                    if (modLen < 16384) {
                        modLine[modLen] = line[i];
                        modLen++;
                    }
                    i++;
                }
            }
            /* Output the modified line */
            for (i = 0; i < modLen; i++) fputc(modLine[i], stdout);
            fputc(10, stdout);
            lineLen = 0;
        } else {
            if (lineLen < 8192) {
                line[lineLen] = c;
                lineLen++;
            }
        }
    }
    /* Handle file without trailing newline */
    if (lineLen > 0) {
        modLen = 0;
        i = 0;
        while (i < lineLen) {
            if (line[i] == 34) {
                strLen = 0;
                i++;
                while (i < lineLen && line[i] != 34) {
                    if (line[i] == 92 && i + 1 < lineLen) {
                        i++;
                        if (strLen < 2048) {
                            str[strLen] = decodeEscape((unsigned char)line[i]);
                            strLen++;
                        }
                        i++;
                    } else {
                        if (strLen < 2048) {
                            str[strLen] = line[i];
                            strLen++;
                        }
                        i++;
                    }
                }
                if (i < lineLen) i++;
                emitDecl(str, strLen, counter);
                emitVarRef(modLine, &modLen, counter);
                counter++;
            } else {
                if (modLen < 16384) {
                    modLine[modLen] = line[i];
                    modLen++;
                }
                i++;
            }
        }
        for (i = 0; i < modLen; i++) fputc(modLine[i], stdout);
        fputc(10, stdout);
    }

    fclose(f);
    return 0;
}
