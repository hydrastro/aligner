#include<stdio.h>

int main()
{
int test[90]={},i=0,j;
char a[90]="\n\n\n"; //"error: no file provided\n";
while(a[i]!='\0') {test[i]=a[i]; i++;}
for(j=0;j<i-1;j++) printf("fputc(%d, stdout);\n",test[j]);
return 0;
}

