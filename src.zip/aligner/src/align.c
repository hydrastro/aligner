/*
 * align.c — line-by-line right-justification.
 *
 * The pipeline:
 *  1. wrap_brace_inits  — for lines that contain top-level brace-init
 *     contents (`{ ..., ..., }`), insert newlines after `{`, after commas,
 *     and before `}`. Lines short enough naturally are left alone.
 *  2. align_line        — for each (possibly newly-broken) line, split into
 *     word-prefix + symbol-tail and right-justify the tail to col 80.
 */

#include "align.h"

#include <string.h>

#define LINE_WIDTH 80

static int is_word(int c) {
    return c == '_'
        || (c >= 'a' && c <= 'z')
        || (c >= 'A' && c <= 'Z')
        || (c >= '0' && c <= '9');
}

static int is_blank(const char *s, size_t n) {
    for (size_t i = 0; i < n; i++) {
        char c = s[i];
        if (c != ' ' && c != '\t' && c != '\r') return 0;
    }
    return 1;
}

static int align_line(const char *line, size_t len, ds_str_t *out) {
    if (is_blank(line, len)) return str_pushc(out, '\n');

    /* Strip leading whitespace. */
    size_t start = 0;
    while (start < len && (line[start] == ' ' || line[start] == '\t')) start++;

    /* Treat a leading `#` (preprocessor directive marker) as part of the
       word prefix. This matches v2's aesthetic: `#include` left, path
       right. Without this hook, the leading `#` is a "symbol" and the
       whole directive ends up right-justified. */
    size_t split = start;
    if (split < len && line[split] == '#') split++;

    /* Find split position: scan until first character that is not (word OR
       horizontal whitespace). */
    while (split < len) {
        char c = line[split];
        if (is_word((unsigned char)c) || c == ' ' || c == '\t') {
            split++;
        } else {
            break;
        }
    }

    /* Strip trailing whitespace from left side. */
    size_t left_end = split;
    while (left_end > start &&
           (line[left_end - 1] == ' ' || line[left_end - 1] == '\t')) {
        left_end--;
    }

    /* Strip trailing whitespace from right side. */
    size_t right_end = len;
    while (right_end > split &&
           (line[right_end - 1] == ' ' || line[right_end - 1] == '\t' ||
            line[right_end - 1] == '\r')) {
        right_end--;
    }

    size_t left_len  = left_end - start;
    size_t right_len = right_end - split;
    int rc = 0;

    if (left_len > 0) {
        rc |= str_append(out, line + start, left_len);
    }

    long natural = (long)left_len + (long)right_len;
    long pad = (long)LINE_WIDTH - natural;
    if (pad > 0) {
        for (long k = 0; k < pad; k++) rc |= str_pushc(out, ' ');
    }

    if (right_len > 0) {
        rc |= str_append(out, line + split, right_len);
    }
    rc |= str_pushc(out, '\n');
    return rc;
}

ds_status_t cfmt_align(const char *in, size_t in_len, ds_str_t *out) {
    /* Phase 1: brace-init wrapping.
     *
     * Walk the input. When we see a `,` at brace-depth >= 1 and not inside
     * any paren AND the current line is already long, insert a newline
     * after it. Same for `{` and `}` boundaries when the current line is
     * long or has content on both sides.
     *
     * "Long" here is: if we already crossed 60 columns since the last
     * newline, splitting helps. (Lower than 80 because we want to leave
     * headroom for the right-justify pad.) */
    ds_str_t *wrapped = str_create();
    if (!wrapped) return DS_ERR_ALLOC;
    int brace = 0;
    int paren = 0;
    int col = 0;  /* non-whitespace bytes since last newline (so already-
                     aligned input with padding spaces doesn't trip us). */
    size_t i = 0;
    /* Block comments and line comments: pass through verbatim, do not
       interpret braces/commas inside them. */
    while (i < in_len) {
        char c = in[i];

        /* Comments: pass through verbatim, do not interpret braces/commas. */
        if (c == '/' && i + 1 < in_len && in[i+1] == '/') {
            while (i < in_len && in[i] != '\n') {
                str_pushc(wrapped, in[i]);
                if (in[i] != ' ' && in[i] != '\t') col++;
                i++;
            }
            continue;
        }
        if (c == '/' && i + 1 < in_len && in[i+1] == '*') {
            while (i < in_len) {
                str_pushc(wrapped, in[i]);
                if (in[i] == '\n') col = 0;
                else if (in[i] != ' ' && in[i] != '\t') col++;
                if (in[i] == '*' && i + 1 < in_len && in[i+1] == '/') {
                    str_pushc(wrapped, '/'); col++;
                    i += 2;
                    break;
                }
                i++;
            }
            continue;
        }

        if (c == '\n') {
            str_pushc(wrapped, '\n');
            col = 0;
            i++;
            continue;
        }
        if (c == ' ' || c == '\t') {
            str_pushc(wrapped, c);
            /* don't count whitespace toward col */
            i++;
            continue;
        }
        if (c == '(') { paren++; str_pushc(wrapped, c); col++; i++; continue; }
        if (c == ')') { if (paren) paren--; str_pushc(wrapped, c); col++; i++; continue; }
        if (c == '{') {
            brace++;
            str_pushc(wrapped, c);
            col++;
            /* If followed by non-newline content and we're getting long,
               insert a newline. */
            if (i + 1 < in_len && in[i+1] != '\n' && col >= 40) {
                str_pushc(wrapped, '\n');
                col = 0;
            }
            i++;
            continue;
        }
        if (c == '}') {
            /* Insert newline before } if line is getting long AND there's
               actual content (not just whitespace) on the line. */
            if (brace > 0 && col >= 40 && i > 0 && in[i-1] != '\n') {
                str_pushc(wrapped, '\n');
                col = 0;
            }
            if (brace) brace--;
            str_pushc(wrapped, c);
            col++;
            i++;
            continue;
        }
        if (c == ',' && brace >= 1 && paren == 0) {
            str_pushc(wrapped, c);
            col++;
            if (i + 1 < in_len && in[i+1] != '\n' && col >= 40) {
                str_pushc(wrapped, '\n');
                col = 0;
                if (i + 1 < in_len && in[i+1] == ' ') i++;
            }
            i++;
            continue;
        }
        str_pushc(wrapped, c);
        col++;
        i++;
    }

    /* Phase 2: align each line. */
    const char *p = FUNC_str_data(wrapped);
    size_t plen = FUNC_str_len(wrapped);
    size_t pi = 0;
    while (pi < plen) {
        size_t j = pi;
        while (j < plen && p[j] != '\n') j++;
        if (align_line(p + pi, j - pi, out) != 0) { str_destroy(wrapped); return DS_ERR_ALLOC; }
        pi = (j < plen) ? j + 1 : j;
    }
    str_destroy(wrapped);
    return DS_OK;
}
