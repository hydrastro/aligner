

#include                                                               <stdio.h>
#include                                                              <stdlib.h>

#define LINE_WIDTH        80
#define MAX_FUNCS         4096
#define MAX_STRS_PER_FUNC 512
#define MAX_FILE_STRS     2048
#define MAX_STR_BYTES     16384
#define MAX_INPUT_BYTES   16777216
#define STRING_POOL_BYTES 8388608



static unsigned int fnv1a                                                      (
const char                                                                     *
data                                                                           ,
int n                                                                         ){

    unsigned int h                                                             ;
    int i                                                                      ;
    h                                                                          =
2166136261u                                                                    ;
    for                                                                        (
i                                                                              =
0                                                                              ;
i                                                                              <
n                                                                              ;
i                                                                           ++){
        h                                                                      =
h                                                                             ^(
unsigned int                                                                  )(
unsigned char                                                                  )
data                                                                           [
i                                                                             ];
        h                                                                      =
h                                                                              *
16777619u                                                                      ;
                                                                               }
    return h                                                                   ;
                                                                               }



typedef struct                                                                 {
    char buf                                                                   [
LINE_WIDTH                                                                    ];
    int w                                                                      ;
    int s                                                                      ;
    int rs                                                                     ;
    int cls                                                                    [
128                                                                           ];
                                                                               }
Aligner                                                                        ;

static void alignInit                                                          (
Aligner                                                                        *
a                                                                             ){

    int i                                                                      ;
    a                                                                         ->
w                                                                              =
0                                                                              ;
a                                                                             ->
s                                                                              =
0                                                                              ;
a                                                                             ->
rs                                                                             =
0                                                                              ;
    for                                                                        (
i                                                                              =
0                                                                              ;
i                                                                              <
128                                                                            ;
i                                                                            ++)
a                                                                             ->
cls                                                                            [
i                                                                             ]=
3                                                                              ;
    for                                                                        (
i                                                                              =
48                                                                             ;
i                                                                              <
58                                                                             ;
i                                                                            ++)
a                                                                             ->
cls                                                                            [
i                                                                             ]=
2                                                                              ;
    for                                                                        (
i                                                                              =
65                                                                             ;
i                                                                              <
91                                                                             ;
i                                                                            ++)
a                                                                             ->
cls                                                                            [
i                                                                             ]=
2                                                                              ;
    for                                                                        (
i                                                                              =
97                                                                             ;
i                                                                              <
123                                                                            ;
i                                                                            ++)
a                                                                             ->
cls                                                                            [
i                                                                             ]=
2                                                                              ;
    a                                                                         ->
cls                                                                            [
95                                                                            ]=
2                                                                              ;
    a                                                                         ->
cls                                                                            [
32                                                                            ]=
1                                                                              ;
a                                                                             ->
cls                                                                            [
9                                                                             ]=
1                                                                              ;
a                                                                             ->
cls                                                                            [
11                                                                            ]=
1                                                                              ;
    a                                                                         ->
cls                                                                            [
12                                                                            ]=
1                                                                              ;
a                                                                             ->
cls                                                                            [
13                                                                            ]=
1                                                                              ;
    a                                                                         ->
cls                                                                            [
10                                                                            ]=
0                                                                              ;
                                                                               }

static void putSpaces                                                          (
int n                                                                         ){
 while                                                                         (
n                                                                            -->
0                                                                              )
fputc                                                                          (
32                                                                             ,
stdout                                                                       );}

static void putBytes                                                           (
const char                                                                     *
b                                                                              ,
int n                                                                         ){

    int i                                                                      ;
    for                                                                        (
i                                                                              =
0                                                                              ;
i                                                                              <
n                                                                              ;
i                                                                            ++)
fputc                                                                          (
b                                                                              [
i                                                                             ],
stdout                                                                        );
                                                                               }

static void alignFeed                                                          (
Aligner                                                                        *
a                                                                              ,
int c                                                                         ){

    int cls                                                                    ;
    if                                                                         (
c                                                                              <
0                                                                             ||
c                                                                              >
127                                                                            )
c                                                                              =
32                                                                             ;
    cls                                                                        =
a                                                                             ->
cls                                                                            [
c                                                                             ];

    if                                                                         (
cls                                                                           ==
2                                                                             ){
        if                                                                     (
a                                                                             ->
s                                                                              >
0                                                                             ){
            int pad                                                            =
LINE_WIDTH                                                                     -
a                                                                             ->
w                                                                              -
a                                                                             ->
s                                                                              ;
            if                                                                 (
pad                                                                            <
0                                                                              )
pad                                                                            =
0                                                                              ;
            putSpaces                                                          (
pad                                                                           );
            putBytes                                                           (
a                                                                             ->
buf                                                                            ,
a                                                                             ->
s                                                                             );
            fputc                                                              (
10                                                                             ,
stdout                                                                        );
            a                                                                 ->
w                                                                              =
0                                                                              ;
a                                                                             ->
s                                                                              =
0                                                                              ;
a                                                                             ->
rs                                                                             =
0                                                                              ;
                                                                               }
        fputc                                                                  (
c                                                                              ,
stdout                                                                        );
        a                                                                     ->
w                                                                            ++;
                                                                               }
else if                                                                        (
cls                                                                           ==
0                                                                             ){
        if                                                                     (
a                                                                             ->
s                                                                              >
0                                                                             ){
            int pad                                                            =
LINE_WIDTH                                                                     -
a                                                                             ->
w                                                                              -
a                                                                             ->
s                                                                              ;
            if                                                                 (
pad                                                                            <
0                                                                              )
pad                                                                            =
0                                                                              ;
            putSpaces                                                          (
pad                                                                           );
            putBytes                                                           (
a                                                                             ->
buf                                                                            ,
a                                                                             ->
s                                                                             );
            a                                                                 ->
s                                                                              =
0                                                                              ;
a                                                                             ->
rs                                                                             =
0                                                                              ;
                                                                               }
        fputc                                                                  (
10                                                                             ,
stdout                                                                        );
        a                                                                     ->
w                                                                              =
0                                                                              ;
                                                                               }
else if                                                                        (
cls                                                                           ==
1                                                                             ){
        if                                                                    (!
a                                                                             ->
rs                                                                            ){
fputc                                                                          (
c                                                                              ,
stdout                                                                        );
a                                                                             ->
w                                                                           ++;}
                                                                               }
else                                                                           {
        if                                                                     (
a                                                                             ->
s                                                                              <
LINE_WIDTH                                                                     -
1                                                                              )
a                                                                             ->
buf                                                                            [
a                                                                             ->
s                                                                           ++]=
c                                                                              ;
        a                                                                     ->
rs                                                                             =
1                                                                              ;
                                                                               }
                                                                               }


static void alignBeginRaw                                                      (
Aligner                                                                        *
a                                                                             ){

    if                                                                         (
a                                                                             ->
s                                                                              >
0                                                                             ){
        int pad                                                                =
LINE_WIDTH                                                                     -
a                                                                             ->
w                                                                              -
a                                                                             ->
s                                                                              ;
        if                                                                     (
pad                                                                            <
0                                                                              )
pad                                                                            =
0                                                                              ;
        putSpaces                                                              (
pad                                                                           );
        putBytes                                                               (
a                                                                             ->
buf                                                                            ,
a                                                                             ->
s                                                                             );
        a                                                                     ->
s                                                                              =
0                                                                              ;
a                                                                             ->
rs                                                                             =
0                                                                              ;
                                                                               }
    if                                                                         (
a                                                                             ->
w                                                                              >
0                                                                             ){
        fputc                                                                  (
10                                                                             ,
stdout                                                                        );
        a                                                                     ->
w                                                                              =
0                                                                              ;
                                                                               }
                                                                               }

static void alignRaw                                                           (
int c                                                                         ){
 fputc                                                                         (
c                                                                              ,
stdout                                                                       );}

static void alignEndRaw                                                        (
Aligner                                                                        *
a                                                                             ){

    a                                                                         ->
w                                                                              =
0                                                                              ;
a                                                                             ->
s                                                                              =
0                                                                              ;
a                                                                             ->
rs                                                                             =
0                                                                              ;
                                                                               }

static void alignFlush                                                         (
Aligner                                                                        *
a                                                                             ){

    if                                                                         (
a                                                                             ->
s                                                                              >
0                                                                             ){
        int pad                                                                =
LINE_WIDTH                                                                     -
a                                                                             ->
w                                                                              -
a                                                                             ->
s                                                                              ;
        if                                                                     (
pad                                                                            <
0                                                                              )
pad                                                                            =
0                                                                              ;
        putSpaces                                                              (
pad                                                                           );
        putBytes                                                               (
a                                                                             ->
buf                                                                            ,
a                                                                             ->
s                                                                             );
                                                                               }
    fputc                                                                      (
10                                                                             ,
stdout                                                                        );
                                                                               }



typedef struct                                                                 {
    unsigned int hash                                                          ;
    int offset                                                                 ;
    int len                                                                    ;
                                                                               }
StrRef                                                                         ;

typedef struct                                                                 {
    StrRef refs                                                                [
MAX_STRS_PER_FUNC                                                             ];
    int count                                                                  ;
                                                                               }
FnStrs                                                                         ;

static FnStrs g_funcs                                                          [
MAX_FUNCS                                                                     ];
static int    g_numFuncs                                                       =
0                                                                              ;
static StrRef g_fileStrs                                                       [
MAX_FILE_STRS                                                                 ];
static int    g_numFileStrs                                                    =
0                                                                              ;
static char   g_pool                                                           [
STRING_POOL_BYTES                                                             ];
static int    g_poolLen                                                        =
0                                                                              ;

static int poolAdd                                                             (
const char                                                                     *
data                                                                           ,
int len                                                                       ){

    int off                                                                    =
g_poolLen                                                                      ;
    int i                                                                      ;
    if                                                                         (
g_poolLen                                                                      +
len                                                                            >
STRING_POOL_BYTES                                                              )
return                                                                         -
1                                                                              ;
    for                                                                        (
i                                                                              =
0                                                                              ;
i                                                                              <
len                                                                            ;
i                                                                            ++)
g_pool                                                                         [
off                                                                            +
i                                                                             ]=
data                                                                           [
i                                                                             ];
    g_poolLen                                                                 +=
len                                                                            ;
    return off                                                                 ;
                                                                               }

static void registerFnString                                                   (
int fi                                                                         ,
const char                                                                     *
data                                                                           ,
int len                                                                        ,
unsigned int h                                                                ){

    FnStrs                                                                     *
f                                                                              ;
    int i                                                                      ,
off                                                                            ;
    if                                                                         (
fi                                                                             <
0                                                                             ||
fi                                                                            >=
MAX_FUNCS                                                                      )
return                                                                         ;
    f                                                                         =&
g_funcs                                                                        [
fi                                                                            ];
    for                                                                        (
i                                                                              =
0                                                                              ;
i                                                                              <
f                                                                             ->
count                                                                          ;
i                                                                           ++){
        if                                                                     (
f                                                                             ->
refs                                                                           [
i                                                                             ].
hash                                                                          ==
h                                                                              )
return                                                                         ;
                                                                               }
    if                                                                         (
f                                                                             ->
count                                                                         >=
MAX_STRS_PER_FUNC                                                              )
return                                                                         ;
    off                                                                        =
poolAdd                                                                        (
data                                                                           ,
len                                                                           );
    if                                                                         (
off                                                                            <
0                                                                              )
return                                                                         ;
    f                                                                         ->
refs                                                                           [
f                                                                             ->
count                                                                         ].
hash                                                                           =
h                                                                              ;
    f                                                                         ->
refs                                                                           [
f                                                                             ->
count                                                                         ].
offset                                                                         =
off                                                                            ;
    f                                                                         ->
refs                                                                           [
f                                                                             ->
count                                                                         ].
len                                                                            =
len                                                                            ;
    f                                                                         ->
count                                                                        ++;
                                                                               }

static void registerFileString                                                 (
const char                                                                     *
data                                                                           ,
int len                                                                        ,
unsigned int h                                                                ){

    int i                                                                      ,
off                                                                            ;
    for                                                                        (
i                                                                              =
0                                                                              ;
i                                                                              <
g_numFileStrs                                                                  ;
i                                                                           ++){
        if                                                                     (
g_fileStrs                                                                     [
i                                                                             ].
hash                                                                          ==
h                                                                              )
return                                                                         ;
                                                                               }
    if                                                                         (
g_numFileStrs                                                                 >=
MAX_FILE_STRS                                                                  )
return                                                                         ;
    off                                                                        =
poolAdd                                                                        (
data                                                                           ,
len                                                                           );
    if                                                                         (
off                                                                            <
0                                                                              )
return                                                                         ;
    g_fileStrs                                                                 [
g_numFileStrs                                                                 ].
hash                                                                           =
h                                                                              ;
    g_fileStrs                                                                 [
g_numFileStrs                                                                 ].
offset                                                                         =
off                                                                            ;
    g_fileStrs                                                                 [
g_numFileStrs                                                                 ].
len                                                                            =
len                                                                            ;
    g_numFileStrs                                                            ++;
                                                                               }



static void emitInt                                                            (
Aligner                                                                        *
a                                                                              ,
int n                                                                         ){

    char d                                                                     [
16                                                                            ];
    int k                                                                      =
0                                                                              ;
    if                                                                         (
n                                                                              <
0                                                                             ){
alignFeed                                                                      (
a                                                                              ,
45                                                                            );
n                                                                             =-
n                                                                             ;}
    if                                                                         (
n                                                                             ==
0                                                                             ){
alignFeed                                                                      (
a                                                                              ,
48                                                                            );
return                                                                        ;}
    while                                                                      (
n                                                                              >
0                                                                             ){
d                                                                              [
k                                                                           ++]=
48                                                                            +(
n                                                                              %
10                                                                            );
n                                                                             /=
10                                                                            ;}
    while                                                                      (
k                                                                              >
0                                                                              )
alignFeed                                                                      (
a                                                                              ,
d                                                                            [--
k                                                                            ]);
                                                                               }

static void emitHex8                                                           (
Aligner                                                                        *
a                                                                              ,
unsigned int h                                                                ){

    int i                                                                      ;
    for                                                                        (
i                                                                              =
28                                                                             ;
i                                                                             >=
0                                                                              ;
i                                                                             -=
4                                                                             ){
        unsigned int nib                                                      =(
h                                                                             >>
i                                                                             )&
0xFu                                                                           ;
        if                                                                     (
nib                                                                            <
10                                                                             )
alignFeed                                                                      (
a                                                                              ,
48                                                                            +(
int                                                                            )
nib                                                                           );
        else          alignFeed                                                (
a                                                                              ,
97                                                                            +(
int                                                                            )
nib                                                                            -
10                                                                            );
                                                                               }
                                                                               }

static void emitVar                                                            (
Aligner                                                                        *
a                                                                              ,
unsigned int h                                                                ){

    alignFeed                                                                  (
a                                                                              ,
115                                                                           );
    emitHex8                                                                   (
a                                                                              ,
h                                                                             );
                                                                               }


static void emitLocalDecl                                                      (
Aligner                                                                        *
a                                                                              ,
const char                                                                     *
content                                                                        ,
int len                                                                        ,
unsigned int h                                                                ){

    int i                                                                      ;
    alignFeed                                                                  (
a                                                                              ,
99                                                                            );
alignFeed                                                                      (
a                                                                              ,
104                                                                           );
alignFeed                                                                      (
a                                                                              ,
97                                                                            );
    alignFeed                                                                  (
a                                                                              ,
114                                                                           );
alignFeed                                                                      (
a                                                                              ,
32                                                                            );
    emitVar                                                                    (
a                                                                              ,
h                                                                             );
    alignFeed                                                                  (
a                                                                              ,
91                                                                            );
    emitInt                                                                    (
a                                                                              ,
len                                                                            +
1                                                                             );
    alignFeed                                                                  (
a                                                                              ,
93                                                                            );
alignFeed                                                                      (
a                                                                              ,
59                                                                            );
alignFeed                                                                      (
a                                                                              ,
10                                                                            );
    for                                                                        (
i                                                                              =
0                                                                              ;
i                                                                              <
len                                                                            ;
i                                                                           ++){
        emitVar                                                                (
a                                                                              ,
h                                                                             );
        alignFeed                                                              (
a                                                                              ,
91                                                                            );
        emitInt                                                                (
a                                                                              ,
i                                                                             );
        alignFeed                                                              (
a                                                                              ,
93                                                                            );
        alignFeed                                                              (
a                                                                              ,
32                                                                            );
alignFeed                                                                      (
a                                                                              ,
61                                                                            );
alignFeed                                                                      (
a                                                                              ,
32                                                                            );
        emitInt                                                                (
a                                                                             ,(
unsigned char                                                                  )
content                                                                        [
i                                                                            ]);
        alignFeed                                                              (
a                                                                              ,
59                                                                            );
alignFeed                                                                      (
a                                                                              ,
10                                                                            );
                                                                               }
    emitVar                                                                    (
a                                                                              ,
h                                                                             );
    alignFeed                                                                  (
a                                                                              ,
91                                                                            );
emitInt                                                                        (
a                                                                              ,
len                                                                           );
alignFeed                                                                      (
a                                                                              ,
93                                                                            );
    alignFeed                                                                  (
a                                                                              ,
32                                                                            );
alignFeed                                                                      (
a                                                                              ,
61                                                                            );
alignFeed                                                                      (
a                                                                              ,
32                                                                            );
    alignFeed                                                                  (
a                                                                              ,
48                                                                            );
    alignFeed                                                                  (
a                                                                              ,
59                                                                            );
alignFeed                                                                      (
a                                                                              ,
10                                                                            );
                                                                               }


static void emitFileDecl                                                       (
Aligner                                                                        *
a                                                                              ,
const char                                                                     *
content                                                                        ,
int len                                                                        ,
unsigned int h                                                                ){

    int i                                                                      ;
    
    alignFeed                                                                  (
a                                                                              ,
115                                                                           );
alignFeed                                                                      (
a                                                                              ,
116                                                                           );
alignFeed                                                                      (
a                                                                              ,
97                                                                            );
    alignFeed                                                                  (
a                                                                              ,
116                                                                           );
alignFeed                                                                      (
a                                                                              ,
105                                                                           );
alignFeed                                                                      (
a                                                                              ,
99                                                                            );
    alignFeed                                                                  (
a                                                                              ,
32                                                                            );
    alignFeed                                                                  (
a                                                                              ,
99                                                                            );
alignFeed                                                                      (
a                                                                              ,
111                                                                           );
alignFeed                                                                      (
a                                                                              ,
110                                                                           );
    alignFeed                                                                  (
a                                                                              ,
115                                                                           );
alignFeed                                                                      (
a                                                                              ,
116                                                                           );
alignFeed                                                                      (
a                                                                              ,
32                                                                            );
    alignFeed                                                                  (
a                                                                              ,
99                                                                            );
alignFeed                                                                      (
a                                                                              ,
104                                                                           );
alignFeed                                                                      (
a                                                                              ,
97                                                                            );
    alignFeed                                                                  (
a                                                                              ,
114                                                                           );
alignFeed                                                                      (
a                                                                              ,
32                                                                            );
    emitVar                                                                    (
a                                                                              ,
h                                                                             );
    alignFeed                                                                  (
a                                                                              ,
91                                                                            );
    emitInt                                                                    (
a                                                                              ,
len                                                                            +
1                                                                             );
    alignFeed                                                                  (
a                                                                              ,
93                                                                            );
    alignFeed                                                                  (
a                                                                              ,
32                                                                            );
alignFeed                                                                      (
a                                                                              ,
61                                                                            );
alignFeed                                                                      (
a                                                                              ,
32                                                                            );
    alignFeed                                                                  (
a                                                                              ,
123                                                                           );
alignFeed                                                                      (
a                                                                              ,
10                                                                            );
    for                                                                        (
i                                                                              =
0                                                                              ;
i                                                                              <
len                                                                            ;
i                                                                           ++){
        emitInt                                                                (
a                                                                             ,(
unsigned char                                                                  )
content                                                                        [
i                                                                            ]);
        alignFeed                                                              (
a                                                                              ,
44                                                                            );
alignFeed                                                                      (
a                                                                              ,
10                                                                            );
                                                                               }
    alignFeed                                                                  (
a                                                                              ,
48                                                                            );
alignFeed                                                                      (
a                                                                              ,
10                                                                            );
    alignFeed                                                                  (
a                                                                              ,
125                                                                           );
alignFeed                                                                      (
a                                                                              ,
59                                                                            );
alignFeed                                                                      (
a                                                                              ,
10                                                                            );
                                                                               }


static void emitBraceInit                                                      (
Aligner                                                                        *
a                                                                              ,
const char                                                                     *
content                                                                        ,
int len                                                                       ){

    int i                                                                      ;
    alignFeed                                                                  (
a                                                                              ,
123                                                                           );
    for                                                                        (
i                                                                              =
0                                                                              ;
i                                                                              <
len                                                                            ;
i                                                                           ++){
        emitInt                                                                (
a                                                                             ,(
unsigned char                                                                  )
content                                                                        [
i                                                                            ]);
        alignFeed                                                              (
a                                                                              ,
44                                                                            );
alignFeed                                                                      (
a                                                                              ,
32                                                                            );
                                                                               }
    alignFeed                                                                  (
a                                                                              ,
48                                                                            );
    alignFeed                                                                  (
a                                                                              ,
125                                                                           );
                                                                               }




static int parseEscape                                                         (
const char                                                                     *
src                                                                            ,
int n                                                                          ,
int                                                                            *
idx                                                                           ){

    int i                                                                     =*
idx                                                                            ;
    int c                                                                      ;
    if                                                                         (
i                                                                             >=
n                                                                              )
return 0                                                                       ;
    c                                                                         =(
unsigned char                                                                  )
src                                                                            [
i                                                                             ];

    
    if                                                                         (
c                                                                             ==
120                                                                           ||
c                                                                             ==
88                                                                            ){
        int val                                                                =
0                                                                              ;
        i                                                                    ++;
        while                                                                  (
i                                                                              <
n                                                                             ){
            int h                                                             =(
unsigned char                                                                  )
src                                                                            [
i                                                                             ];
            int d                                                              ;
            if                                                                 (
h                                                                             >=
48                                                                            &&
h                                                                             <=
57                                                                             )
d                                                                              =
h                                                                              -
48                                                                             ;
            else if                                                            (
h                                                                             >=
97                                                                            &&
h                                                                             <=
102                                                                            )
d                                                                              =
h                                                                              -
87                                                                             ;
            else if                                                            (
h                                                                             >=
65                                                                            &&
h                                                                             <=
70                                                                             )
d                                                                              =
h                                                                              -
55                                                                             ;
            else break                                                         ;
            val                                                               =(
val                                                                           <<
4                                                                             )|
d                                                                              ;
            i                                                                ++;
                                                                               }
                                                                               *
idx                                                                            =
i                                                                              ;
        return val                                                             &
0xFF                                                                           ;
                                                                               }

    
    if                                                                         (
c                                                                             >=
48                                                                            &&
c                                                                             <=
55                                                                            ){
        int val                                                                =
0                                                                              ;
        int count                                                              =
0                                                                              ;
        while                                                                  (
i                                                                              <
n                                                                             &&
count                                                                          <
3                                                                             ){
            int o                                                             =(
unsigned char                                                                  )
src                                                                            [
i                                                                             ];
            if                                                                 (
o                                                                              <
48                                                                            ||
o                                                                              >
55                                                                             )
break                                                                          ;
            val                                                               =(
val                                                                            *
8                                                                            )+(
o                                                                              -
48                                                                            );
            i                                                                ++;
            count                                                            ++;
                                                                               }
                                                                               *
idx                                                                            =
i                                                                              ;
        return val                                                             &
0xFF                                                                           ;
                                                                               }

    
                                                                               *
idx                                                                            =
i                                                                              +
1                                                                              ;
    if                                                                         (
c                                                                             ==
110                                                                            )
return 10                                                                      ;
    if                                                                         (
c                                                                             ==
116                                                                            )
return 9                                                                       ;
    if                                                                         (
c                                                                             ==
114                                                                            )
return 13                                                                      ;
    if                                                                         (
c                                                                             ==
92                                                                             )
return 92                                                                      ;
    if                                                                         (
c                                                                             ==
34                                                                             )
return 34                                                                      ;
    if                                                                         (
c                                                                             ==
39                                                                             )
return 39                                                                      ;
    if                                                                         (
c                                                                             ==
97                                                                             )
return 7                                                                       ;
    if                                                                         (
c                                                                             ==
98                                                                             )
return 8                                                                       ;
    if                                                                         (
c                                                                             ==
102                                                                            )
return 12                                                                      ;
    if                                                                         (
c                                                                             ==
118                                                                            )
return 11                                                                      ;
    if                                                                         (
c                                                                             ==
63                                                                             )
return 63                                                                      ;
    return c                                                                   ;
                                                                               }



static char g_strBuf                                                           [
MAX_STR_BYTES                                                                 ];

static int parseString                                                         (
const char                                                                     *
src                                                                            ,
int n                                                                          ,
int                                                                            *
idx                                                                           ){

    int i                                                                     =*
idx                                                                            ;
    int sl                                                                     =
0                                                                              ;
    if                                                                         (
i                                                                             >=
n                                                                            ||(
unsigned char                                                                  )
src                                                                            [
i                                                                            ]!=
34                                                                             )
return                                                                         -
1                                                                              ;
    i                                                                        ++;
    for                                                                    (;;){
        while                                                                  (
i                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                            ]!=
34                                                                            ){
            int b                                                              ;
            if                                                                ((
unsigned char                                                                  )
src                                                                            [
i                                                                            ]==
92                                                                            &&
i                                                                              +
1                                                                              <
n                                                                             ){
                
                if                                                            ((
unsigned char                                                                  )
src                                                                            [
i                                                                              +
1                                                                            ]==
10                                                                            ){
                    i                                                         +=
2                                                                              ;
                    continue                                                   ;
                                                                               }
                i                                                            ++;
                b                                                              =
parseEscape                                                                    (
src                                                                            ,
n                                                                             ,&
i                                                                             );
                                                                               }
else                                                                           {
                b                                                             =(
unsigned char                                                                  )
src                                                                            [
i                                                                             ];
                i                                                            ++;
                                                                               }
            if                                                                 (
sl                                                                             <
MAX_STR_BYTES                                                                  )
g_strBuf                                                                       [
sl                                                                          ++]=
b                                                                              ;
                                                                               }
        if                                                                     (
i                                                                              <
n                                                                              )
i                                                                            ++;
        
                                                                               {
            int j                                                              =
i                                                                              ;
            while                                                              (
j                                                                              <
n                                                                             ){
                unsigned char cc                                              =(
unsigned char                                                                  )
src                                                                            [
j                                                                             ];
                if                                                             (
cc                                                                            ==
32                                                                            ||
cc                                                                            ==
9                                                                             ||
cc                                                                            ==
10                                                                            ||
cc                                                                            ==
13                                                                            ){
                    j                                                        ++;
                                                                               }
else if                                                                        (
cc                                                                            ==
92                                                                            &&
j                                                                              +
1                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
j                                                                              +
1                                                                            ]==
10                                                                            ){
                    j                                                         +=
2                                                                              ;
                                                                               }
else                                                                           {
                    break                                                      ;
                                                                               }
                                                                               }
            if                                                                 (
j                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
j                                                                            ]==
34                                                                            ){
                i                                                              =
j                                                                              +
1                                                                              ;
                continue                                                       ;
                                                                               }
                                                                               }
        break                                                                  ;
                                                                               }
                                                                               *
idx                                                                            =
i                                                                              ;
    return sl                                                                  ;
                                                                               }


static int wideStringPrefixLen                                                 (
const char                                                                     *
src                                                                            ,
int n                                                                          ,
int i                                                                         ){

    if                                                                         (
i                                                                             >=
n                                                                              )
return 0                                                                       ;
    unsigned char c                                                           =(
unsigned char                                                                  )
src                                                                            [
i                                                                             ];
    if                                                                         (
c                                                                             ==
76                                                                            ){
        if                                                                     (
i                                                                              +
1                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                              +
1                                                                            ]==
34                                                                             )
return 1                                                                       ;
                                                                               }
else if                                                                        (
c                                                                             ==
117                                                                           ){
        if                                                                     (
i                                                                              +
1                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                              +
1                                                                            ]==
34                                                                             )
return 1                                                                       ;
        if                                                                     (
i                                                                              +
2                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                              +
1                                                                            ]==
56                                                                           &&(
unsigned char                                                                  )
src                                                                            [
i                                                                              +
2                                                                            ]==
34                                                                             )
return 2                                                                       ;
                                                                               }
else if                                                                        (
c                                                                             ==
85                                                                            ){
        if                                                                     (
i                                                                              +
1                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                              +
1                                                                            ]==
34                                                                             )
return 1                                                                       ;
                                                                               }
    return 0                                                                   ;
                                                                               }



static int isWS                                                                (
int c                                                                         ){

    return c                                                                  ==
32                                                                            ||
c                                                                             ==
9                                                                             ||
c                                                                             ==
10                                                                            ||
c                                                                             ==
11                                                                            ||
c                                                                             ==
12                                                                            ||
c                                                                             ==
13                                                                             ;
                                                                               }


static int prevSigChar                                                         (
const char                                                                     *
src                                                                            ,
int i                                                                         ){

    while                                                                      (
i                                                                              >
0                                                                             ){
        i                                                                    --;
        if                                                                    (!
isWS                                                                          ((
unsigned char                                                                  )
src                                                                            [
i                                                                            ]))
return                                                                         (
unsigned char                                                                  )
src                                                                            [
i                                                                             ];
                                                                               }
    return 0                                                                   ;
                                                                               }


static int prevSigChar2                                                        (
const char                                                                     *
src                                                                            ,
int i                                                                         ){

    int found                                                                  =
0                                                                              ;
    while                                                                      (
i                                                                              >
0                                                                             ){
        i                                                                    --;
        if                                                                    (!
isWS                                                                          ((
unsigned char                                                                  )
src                                                                            [
i                                                                           ])){
            if                                                                 (
found                                                                          )
return                                                                         (
unsigned char                                                                  )
src                                                                            [
i                                                                             ];
            found                                                              =
1                                                                              ;
                                                                               }
                                                                               }
    return 0                                                                   ;
                                                                               }


static int isInclude                                                           (
const char                                                                     *
src                                                                            ,
int n                                                                          ,
int i                                                                         ){

    static const unsigned char want                                            [
8                                                                            ]={
35                                                                             ,
105                                                                            ,
110                                                                            ,
99                                                                             ,
108                                                                            ,
117                                                                            ,
100                                                                            ,
101                                                                           };
    int j                                                                      ;
    if                                                                         (
i                                                                              +
8                                                                              >
n                                                                              )
return 0                                                                       ;
    for                                                                        (
j                                                                              =
0                                                                              ;
j                                                                              <
8                                                                              ;
j                                                                           ++){
        if                                                                    ((
unsigned char                                                                  )
src                                                                            [
i                                                                              +
j                                                                            ]!=
want                                                                           [
j                                                                             ])
return 0                                                                       ;
                                                                               }
    return 1                                                                   ;
                                                                               }


static int emitIncludeAligned                                                  (
const char                                                                     *
src                                                                            ,
int n                                                                          ,
int i                                                                          ,
Aligner                                                                        *
a                                                                             ){

    char tail                                                                  [
LINE_WIDTH                                                                    ];
    int tailLen                                                                =
0                                                                              ;
    int j                                                                      ;
    
    for                                                                        (
j                                                                              =
0                                                                              ;
j                                                                              <
8                                                                              ;
j                                                                            ++)
fputc                                                                         ((
unsigned char                                                                  )
src                                                                            [
i                                                                              +
j                                                                             ],
stdout                                                                        );
    i                                                                         +=
8                                                                              ;
    
    while                                                                      (
i                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                            ]!=
10                                                                            ){
        unsigned char c                                                       =(
unsigned char                                                                  )
src                                                                            [
i                                                                             ];
        if                                                                     (
c                                                                             !=
32                                                                            &&
c                                                                             !=
9                                                                             &&
c                                                                             !=
11                                                                            &&
c                                                                             !=
12                                                                            &&
c                                                                             !=
13                                                                            ){
            if                                                                 (
tailLen                                                                        <
LINE_WIDTH                                                                     -
1                                                                              )
tail                                                                           [
tailLen                                                                     ++]=
c                                                                              ;
                                                                               }
        i                                                                    ++;
                                                                               }
    if                                                                         (
i                                                                              <
n                                                                              )
i                                                                            ++;
    
                                                                               {
        int pad                                                                =
LINE_WIDTH                                                                     -
8                                                                              -
tailLen                                                                        ;
        if                                                                     (
pad                                                                            <
0                                                                              )
pad                                                                            =
0                                                                              ;
        for                                                                    (
j                                                                              =
0                                                                              ;
j                                                                              <
pad                                                                            ;
j                                                                            ++)
fputc                                                                          (
32                                                                             ,
stdout                                                                        );
        for                                                                    (
j                                                                              =
0                                                                              ;
j                                                                              <
tailLen                                                                        ;
j                                                                            ++)
fputc                                                                          (
tail                                                                           [
j                                                                             ],
stdout                                                                        );
                                                                               }
    fputc                                                                      (
10                                                                             ,
stdout                                                                        );
    alignEndRaw                                                                (
a                                                                             );
    return i                                                                   ;
                                                                               }


static int skipPreprocessor                                                    (
const char                                                                     *
src                                                                            ,
int n                                                                          ,
int i                                                                          ,
Aligner                                                                        *
a                                                                              ,
int pass                                                                      ){

    
    if                                                                         (
isInclude                                                                      (
src                                                                            ,
n                                                                              ,
i                                                                            )){
        if                                                                     (
pass                                                                          ){
            alignBeginRaw                                                      (
a                                                                             );
            return emitIncludeAligned                                          (
src                                                                            ,
n                                                                              ,
i                                                                              ,
a                                                                             );
                                                                               }
        
        while                                                                  (
i                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                            ]!=
10                                                                             )
i                                                                            ++;
        if                                                                     (
i                                                                              <
n                                                                              )
i                                                                            ++;
        return i                                                               ;
                                                                               }
    
    if                                                                         (
pass                                                                           )
alignBeginRaw                                                                  (
a                                                                             );
    while                                                                      (
i                                                                              <
n                                                                             ){
        int c                                                                 =(
unsigned char                                                                  )
src                                                                            [
i                                                                             ];
        if                                                                     (
c                                                                             ==
10                                                                            ){
            if                                                                 (
pass                                                                           )
alignRaw                                                                       (
10                                                                            );
            i                                                                ++;
            break                                                              ;
                                                                               }
        if                                                                     (
c                                                                             ==
92                                                                            &&
i                                                                              +
1                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                              +
1                                                                            ]==
10                                                                            ){
            if                                                                 (
pass                                                                          ){
alignRaw                                                                       (
92                                                                            );
alignRaw                                                                       (
10                                                                           );}
            i                                                                 +=
2                                                                              ;
            continue                                                           ;
                                                                               }
        if                                                                     (
pass                                                                           )
alignRaw                                                                       (
c                                                                             );
        i                                                                    ++;
                                                                               }
    if                                                                         (
pass                                                                           )
alignEndRaw                                                                    (
a                                                                             );
    return i                                                                   ;
                                                                               }


static int atLineStart                                                         (
const char                                                                     *
src                                                                            ,
int i                                                                         ){

    while                                                                      (
i                                                                              >
0                                                                             ){
        int c                                                                 =(
unsigned char                                                                  )
src                                                                            [
i                                                                              -
1                                                                             ];
        if                                                                     (
c                                                                             ==
10                                                                             )
return 1                                                                       ;
        if                                                                    (!
isWS                                                                           (
c                                                                             ))
return 0                                                                       ;
        i                                                                    --;
                                                                               }
    return 1                                                                   ;
                                                                               }

static void scan                                                               (
const char                                                                     *
src                                                                            ,
int n                                                                          ,
Aligner                                                                        *
a                                                                              ,
int pass                                                                      ){

    int inBC                                                                   =
0                                                                              ;
    int depth                                                                  =
0                                                                              ;
    int fi                                                                    =-
1                                                                              ;
    int fnCounter                                                              =
0                                                                              ;
    int i                                                                      =
0                                                                              ;

    while                                                                      (
i                                                                              <
n                                                                             ){
        int c                                                                 =(
unsigned char                                                                  )
src                                                                            [
i                                                                             ];

        if                                                                     (
inBC                                                                          ){
            if                                                                 (
c                                                                             ==
42                                                                            &&
i                                                                              +
1                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                              +
1                                                                            ]==
47                                                                            ){
                inBC                                                           =
0                                                                              ;
                i                                                             +=
2                                                                              ;
                                                                               }
else                                                                           {
                i                                                            ++;
                                                                               }
            continue                                                           ;
                                                                               }

        if                                                                     (
c                                                                             ==
47                                                                            &&
i                                                                              +
1                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                              +
1                                                                            ]==
42                                                                            ){
            inBC                                                               =
1                                                                              ;
            i                                                                 +=
2                                                                              ;
            continue                                                           ;
                                                                               }

        if                                                                     (
c                                                                             ==
47                                                                            &&
i                                                                              +
1                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                              +
1                                                                            ]==
47                                                                            ){
            while                                                              (
i                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
i                                                                            ]!=
10                                                                             )
i                                                                            ++;
            continue                                                           ;
                                                                               }

        
        if                                                                     (
c                                                                             ==
35                                                                            &&
atLineStart                                                                    (
src                                                                            ,
i                                                                            )){
            i                                                                  =
skipPreprocessor                                                               (
src                                                                            ,
n                                                                              ,
i                                                                              ,
a                                                                              ,
pass                                                                          );
            continue                                                           ;
                                                                               }

        
        if                                                                     (
c                                                                             ==
39                                                                            ){
            int valid                                                          =
0                                                                              ;
            int val                                                            =
0                                                                              ;
            int j                                                              =
i                                                                              +
1                                                                              ;
            if                                                                 (
j                                                                              <
n                                                                             ){
                if                                                            ((
unsigned char                                                                  )
src                                                                            [
j                                                                            ]==
92                                                                            &&
j                                                                              +
1                                                                              <
n                                                                             ){
                    j                                                        ++;
                    val                                                        =
parseEscape                                                                    (
src                                                                            ,
n                                                                             ,&
j                                                                             );
                                                                               }
else if                                                                       ((
unsigned char                                                                  )
src                                                                            [
j                                                                            ]!=
39                                                                            ){
                    val                                                       =(
unsigned char                                                                  )
src                                                                            [
j                                                                             ];
                    j                                                        ++;
                                                                               }
                if                                                             (
j                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
j                                                                            ]==
39                                                                            ){
                    valid                                                      =
1                                                                              ;
                    if                                                         (
pass                                                                           )
emitInt                                                                        (
a                                                                              ,
val                                                                           );
                    i                                                          =
j                                                                              +
1                                                                              ;
                                                                               }
                                                                               }
            if                                                                (!
valid                                                                         ){
                if                                                             (
pass                                                                           )
alignFeed                                                                      (
a                                                                              ,
c                                                                             );
                i                                                            ++;
                                                                               }
            continue                                                           ;
                                                                               }

        
                                                                               {
            int pl                                                             =
wideStringPrefixLen                                                            (
src                                                                            ,
n                                                                              ,
i                                                                             );
            if                                                                 (
pl                                                                             >
0                                                                             ){
                int j                                                          ;
                if                                                             (
pass                                                                          ){
                    alignBeginRaw                                              (
a                                                                             );
                    for                                                        (
j                                                                              =
0                                                                              ;
j                                                                              <
pl                                                                             ;
j                                                                            ++)
alignRaw                                                                      ((
unsigned char                                                                  )
src                                                                            [
i                                                                              +
j                                                                            ]);
                                                                               }
                j                                                              =
i                                                                              +
pl                                                                             ;
                if                                                             (
j                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
j                                                                            ]==
34                                                                            ){
                    if                                                         (
pass                                                                           )
alignRaw                                                                       (
34                                                                            );
                    j                                                        ++;
                    while                                                      (
j                                                                              <
n                                                                            &&(
unsigned char                                                                  )
src                                                                            [
j                                                                            ]!=
34                                                                            ){
                        if                                                    ((
unsigned char                                                                  )
src                                                                            [
j                                                                            ]==
92                                                                            &&
j                                                                              +
1                                                                              <
n                                                                             ){
                            if                                                 (
pass                                                                          ){
alignRaw                                                                      ((
unsigned char                                                                  )
src                                                                            [
j                                                                            ]);
alignRaw                                                                      ((
unsigned char                                                                  )
src                                                                            [
j                                                                              +
1                                                                           ]);}
                            j                                                 +=
2                                                                              ;
                                                                               }
else                                                                           {
                            if                                                 (
pass                                                                           )
alignRaw                                                                      ((
unsigned char                                                                  )
src                                                                            [
j                                                                            ]);
                            j                                                ++;
                                                                               }
                                                                               }
                    if                                                         (
j                                                                              <
n                                                                             ){
                        if                                                     (
pass                                                                           )
alignRaw                                                                       (
34                                                                            );
                        j                                                    ++;
                                                                               }
                                                                               }
                if                                                             (
pass                                                                          ){
alignRaw                                                                       (
10                                                                            );
alignEndRaw                                                                    (
a                                                                            );}
                i                                                              =
j                                                                              ;
                continue                                                       ;
                                                                               }
                                                                               }

        
        if                                                                     (
c                                                                             ==
34                                                                            ){
            int strStart                                                       =
i                                                                              ;
            int sl                                                             =
parseString                                                                    (
src                                                                            ,
n                                                                             ,&
i                                                                             );
            if                                                                 (
sl                                                                             <
0                                                                             ){
                if                                                             (
pass                                                                           )
alignFeed                                                                      (
a                                                                              ,
c                                                                             );
                i                                                            ++;
                continue                                                       ;
                                                                               }
                                                                               {
                unsigned int h                                                 =
fnv1a                                                                          (
g_strBuf                                                                       ,
sl                                                                            );
                
                int p1                                                         =
prevSigChar                                                                    (
src                                                                            ,
strStart                                                                      );
                int p2                                                         =
prevSigChar2                                                                   (
src                                                                            ,
strStart                                                                      );
                int isArrayInit                                               =(
p1                                                                            ==
61                                                                            &&
p2                                                                            ==
93                                                                            );

                if                                                             (
isArrayInit                                                                   ){
                    if                                                         (
pass                                                                           )
emitBraceInit                                                                  (
a                                                                              ,
g_strBuf                                                                       ,
sl                                                                            );
                                                                               }
else if                                                                        (
fi                                                                            >=
0                                                                             ){
                    if                                                        (!
pass                                                                           )
registerFnString                                                               (
fi                                                                             ,
g_strBuf                                                                       ,
sl                                                                             ,
h                                                                             );
                    else       emitVar                                         (
a                                                                              ,
h                                                                             );
                                                                               }
else                                                                           {
                    if                                                        (!
pass                                                                           )
registerFileString                                                             (
g_strBuf                                                                       ,
sl                                                                             ,
h                                                                             );
                    else       emitVar                                         (
a                                                                              ,
h                                                                             );
                                                                               }
                                                                               }
                                                                               (
void                                                                           )
strStart                                                                       ;
            continue                                                           ;
                                                                               }

        
        if                                                                     (
c                                                                             ==
123                                                                           ){
            int isFnEntry                                                      =
0                                                                              ;
            if                                                                 (
depth                                                                         ==
0                                                                             ){
                int ps                                                         =
prevSigChar                                                                    (
src                                                                            ,
i                                                                             );
                if                                                             (
ps                                                                            ==
41                                                                             )
isFnEntry                                                                      =
1                                                                              ;
                                                                               }
            depth                                                            ++;
            if                                                                 (
isFnEntry                                                                     ){
                if                                                            (!
pass                                                                          ){
                    fi                                                         =
g_numFuncs                                                                     ;
                    if                                                         (
g_numFuncs                                                                     <
MAX_FUNCS                                                                     ){
                        g_funcs                                                [
g_numFuncs                                                                    ].
count                                                                          =
0                                                                              ;
                        g_numFuncs                                           ++;
                                                                               }
                                                                               }
else                                                                           {
                    int k                                                      ;
                    FnStrs                                                     *
f                                                                              ;
                    fi                                                         =
fnCounter                                                                      ;
                    fnCounter                                                ++;
                    alignFeed                                                  (
a                                                                              ,
123                                                                           );
                    alignFeed                                                  (
a                                                                              ,
10                                                                            );
                    if                                                         (
fi                                                                             <
MAX_FUNCS                                                                     ){
                        f                                                     =&
g_funcs                                                                        [
fi                                                                            ];
                        for                                                    (
k                                                                              =
0                                                                              ;
k                                                                              <
f                                                                             ->
count                                                                          ;
k                                                                           ++){
                            emitLocalDecl                                      (
a                                                                              ,
                                                                               &
g_pool                                                                         [
f                                                                             ->
refs                                                                           [
k                                                                             ].
offset                                                                        ],
                                          f                                   ->
refs                                                                           [
k                                                                             ].
len                                                                            ,
                                          f                                   ->
refs                                                                           [
k                                                                             ].
hash                                                                          );
                                                                               }
                                                                               }
                    i                                                        ++;
                    continue                                                   ;
                                                                               }
                                                                               }
            if                                                                 (
pass                                                                           )
alignFeed                                                                      (
a                                                                              ,
c                                                                             );
            i                                                                ++;
            continue                                                           ;
                                                                               }

        if                                                                     (
c                                                                             ==
125                                                                           ){
            depth                                                            --;
            if                                                                 (
depth                                                                         <=
0                                                                             ){
depth                                                                          =
0                                                                              ;
fi                                                                            =-
1                                                                             ;}
            if                                                                 (
pass                                                                           )
alignFeed                                                                      (
a                                                                              ,
c                                                                             );
            i                                                                ++;
            continue                                                           ;
                                                                               }

        if                                                                     (
pass                                                                           )
alignFeed                                                                      (
a                                                                              ,
c                                                                             );
        i                                                                    ++;
                                                                               }
                                                                               }



static int readFile                                                            (
const char                                                                     *
path                                                                           ,
char                                                                           *
buf                                                                            ,
int maxLen                                                                    ){

    FILE                                                                       *
f                                                                              ;
    char rb                                                                    [
3                                                                             ];
    size_t got                                                                 ;
    rb                                                                         [
0                                                                             ]=
114                                                                            ;
rb                                                                             [
1                                                                             ]=
98                                                                             ;
rb                                                                             [
2                                                                             ]=
0                                                                              ;
    f                                                                          =
fopen                                                                          (
path                                                                           ,
rb                                                                            );
    if                                                                        (!
f                                                                              )
return                                                                         -
1                                                                              ;
    got                                                                        =
fread                                                                          (
buf                                                                            ,
1                                                                             ,(
size_t                                                                         )
maxLen                                                                         ,
f                                                                             );
    fclose                                                                     (
f                                                                             );
    return                                                                     (
int                                                                            )
got                                                                            ;
                                                                               }



static void emitMsg                                                            (
const int                                                                      *
codes                                                                         ){

    int i                                                                      ;
    for                                                                        (
i                                                                              =
0                                                                              ;
codes                                                                          [
i                                                                            ]>=
0                                                                              ;
i                                                                            ++)
fputc                                                                          (
codes                                                                          [
i                                                                             ],
stderr                                                                        );
                                                                               }

static const int err1                                                       []={
    101                                                                        ,
114                                                                            ,
114                                                                            ,
111                                                                            ,
114                                                                            ,
58                                                                             ,
32                                                                             ,
110                                                                            ,
111                                                                            ,
32                                                                             ,
102                                                                            ,
105                                                                            ,
108                                                                            ,
101                                                                            ,
32                                                                             ,
    112                                                                        ,
114                                                                            ,
111                                                                            ,
118                                                                            ,
105                                                                            ,
100                                                                            ,
101                                                                            ,
100                                                                            ,
10                                                                            ,-
1
                                                                              };
static const int err2                                                       []={
    97                                                                         ,
110                                                                            ,
32                                                                             ,
101                                                                            ,
114                                                                            ,
114                                                                            ,
111                                                                            ,
114                                                                            ,
32                                                                             ,
111                                                                            ,
99                                                                             ,
99                                                                             ,
117                                                                            ,
114                                                                            ,
114                                                                            ,
101                                                                            ,
100                                                                            ,
32                                                                             ,
    119                                                                        ,
104                                                                            ,
105                                                                            ,
108                                                                            ,
101                                                                            ,
32                                                                             ,
111                                                                            ,
112                                                                            ,
101                                                                            ,
110                                                                            ,
105                                                                            ,
110                                                                            ,
103                                                                            ,
32                                                                             ,
102                                                                            ,
105                                                                            ,
108                                                                            ,
    101                                                                        ,
10                                                                            ,-
1
                                                                              };



static char g_input                                                            [
MAX_INPUT_BYTES                                                               ];

int main                                                                       (
int argc                                                                       ,
const char                                                                     *
argv                                                                        []){

    int n                                                                      ,
i                                                                              ;
    Aligner a                                                                  ;
    setbuf                                                                     (
stdout                                                                         ,
NULL                                                                          );
    if                                                                         (
argc                                                                           <
2                                                                             ){
emitMsg                                                                        (
err1                                                                          );
return 1                                                                      ;}
    n                                                                          =
readFile                                                                       (
argv                                                                           [
1                                                                             ],
g_input                                                                        ,
MAX_INPUT_BYTES                                                               );
    if                                                                         (
n                                                                              <
0                                                                             ){
emitMsg                                                                        (
err2                                                                          );
return 1                                                                      ;}

    scan                                                                       (
g_input                                                                        ,
n                                                                              ,
NULL                                                                           ,
0                                                                             );

    alignInit                                                                 (&
a                                                                             );
    
    for                                                                        (
i                                                                              =
0                                                                              ;
i                                                                              <
g_numFileStrs                                                                  ;
i                                                                           ++){
        emitFileDecl                                                          (&
a                                                                              ,
                                                                               &
g_pool                                                                         [
g_fileStrs                                                                     [
i                                                                             ].
offset                                                                        ],
                     g_fileStrs                                                [
i                                                                             ].
len                                                                            ,
                     g_fileStrs                                                [
i                                                                             ].
hash                                                                          );
                                                                               }
    scan                                                                       (
g_input                                                                        ,
n                                                                             ,&
a                                                                              ,
1                                                                             );
    alignFlush                                                                (&
a                                                                             );
    return 0                                                                   ;
                                                                               }

