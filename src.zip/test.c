#include <stdio.h>

int x(void){
return 3>4;
}

int main(void){

printf("%b", x());
}
