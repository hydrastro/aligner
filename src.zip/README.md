# aligner

A C source formatter that aligns every line of code so alphanumeric tokens
hug the left margin and symbols hug column 80. Because string literals,
character literals, and comments can't survive that aesthetic intact, the
program also:

- replaces every string literal with a byte-by-byte declaration whose
  variable name is the FNV-1a hash of the content (`s2cdd8587`, `scfbe045a`,
  …)
- replaces every character literal with its numeric value (`'A'` → `65`)
- strips every comment (the source has none after; their visual weight
  would jar against alignment)
- deduplicates literals within each scope (same content → one declaration)
- concatenates adjacent string literals (`"foo" "bar"` is one literal)
- right-justifies `#include` paths to col 80 (the iconic look)
- leaves wide strings (`L"…"`, `u"…"`, `U"…"`, `u8"…"`) untouched

The output compiles and runs identically to the input.

```
$ ./build/aligner tests/corpus/01_hello.c | head -3
#include                                                               <stdio.h>
int main                                                                (void) {
static const char scfbe045a                                               [15]={
```

## Build

### With Nix

```sh
nix build
./result/bin/aligner some-file.c > formatted.c
nix develop           # gcc, make, gdb, valgrind, clangd, bear
```

### With make

```sh
make
./build/aligner some-file.c
make                  # build ./build/aligner
make test             # full test suite (5 stages, 62 tests)
make clean            # remove build artifacts
make distclean        # remove all generated/transient files; back to a fresh checkout
```

## Architecture

```
source bytes
    ↓
 lexer        → token stream  (lossless: every byte covered)
    ↓
 parser       → AST           (coarse: TU / PP / DECL / FUNC_DEF / BLOCK)
    ↓
 destring     → actions       (per-token replacement plan + per-scope
                               literal tables)
    ↓
 emitter      → unaligned text (applies actions; inserts declarations at
                                file scope and at each function-body open)
    ↓
 aligner      → final text     (brace-wrap pass; then 80-col right-justify
                                of every line)
```

The point of building an AST is that transformations become principled.
`char arr[] = "..."` becomes obvious from the parent node's shape.
Function-scope vs file-scope literals are an attribute of which AST node
owns them. K&R declarators, adjacent strings, struct initializers, arrays
of `char *` literals — each is a node-shape or token-window problem rather
than a tokenizer hack.

We do not run the preprocessor. Files with macro-heavy logic should be
piped through `gcc -E -P` first.

We do not type-check or resolve names. The AST is structural only. For
ambiguous cases (e.g. a struct with both `char[]` and `char *` fields), see
`LIMITS.md`.

## Tests

```
make test         # all 5 stages
```

| Stage | What it checks |
|-------|---|
| lexer        | Concatenating all token lexemes equals the original source (lossless) |
| parser       | Every non-EOF token is owned by exactly one deepest AST node; brace pairings are valid |
| integration  | format → compile → run → diff stdout against original |
| idempotence  | `aligner(aligner(x))` is byte-identical to `aligner(x)` |
| self-format  | Build aligner from its own self-formatted source; verify byte-identical output |

Current status: **62 of 62 passing**, including 10 integration tests, 10
idempotence tests, and the self-format check.

## Layout

```
flake.nix              Nix build + dev shell
Makefile               make / make test
src/
  lexer.h/.c           tokenizer
  ast.h/.c             AST node types
  parser.h/.c          token stream → AST
  pass.h               pass framework
  pass_destring.c      destringer / dechar pass
  emit.h/.c            AST + actions → unaligned text
  align.h/.c           brace-wrap + right-justify
  main.c               CLI
tests/
  corpus/              input programs
  runner.sh            test driver
ds/                    data-structures library this project depends on
```

## CLI

```
aligner FILE              full pipeline → stdout (default)
aligner --lex FILE        dump tokens
aligner --ast FILE        dump AST
aligner --destring FILE   show planned literal lift decisions
aligner --emit FILE       emit unaligned post-destring text (skip aligner)
```

## What works

See `LIMITS.md` for the full accounting. Highlights:

- Arbitrary input size (no fixed buffers)
- All C escape forms incl. `\uHHHH`, `\UHHHHHHHH`, `\xHH`, octal, simple
- All character prefixes (`L`, `u`, `U`, `u8`)
- C23 digit separators
- K&R-style function definitions
- Multi-line string literals (`\<newline>` continuation)
- Adjacent string concatenation
- Per-function and file-scope dedup
- Static-storage lifetime for lifted literals (no dangling pointers)
- Array-init vs pointer-init context detection via declarator inspection
- Self-formatting; idempotence
- 1300+-line production files (`hash_table.c`, `allocators.c`, …) format
  cleanly and recompile

## What doesn't

See `LIMITS.md`. The biggest still-open items: running `cpp` first,
handling mixed-type aggregate inits where some fields are `char[]` and
others `char *`, and teaching aligner about printf-family functions so
format-string warnings survive.
