#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <stdlib.h>

int main (int argc, const char * argv[]) {
    setbuf(stdout, NULL);
    FILE *stream;
    char outputBuffer[80];
    char readChar[1];
    int writtenChars;
    bool readingSymbols;
    int readSymbols;
    int i;
    if(argc < 2){
        fprintf(stderr, "error: no file provided\n");

        return -1;
    }
    stream = fopen(argv[1], "rb");
    if(stream == NULL){
        fprintf(stderr, "an error occured while opening file\n");

        return -1;
    }
    writtenChars = 0;
    readSymbols = 0;
    readingSymbols = false;
    while(fread(readChar, sizeof(char), 1, stream) == 1){
        if(writtenChars == 0 && *readChar == '#') {
           fseek (stream, 7, SEEK_CUR );
           fprintf(stdout, "#include");
           while(fread(readChar, sizeof(char), 1, stream) == 1 && *readChar != '\n') {
               if(!isspace(*readChar)) {
                   outputBuffer[readSymbols] = *readChar;
                   readSymbols++;
               }
           }
           for(i = 0; i < 72 - readSymbols; i++){
               fprintf(stdout, " ");
           }
           for(i = 0; i < readSymbols; i++){
               fprintf(stdout, "%c", outputBuffer[i]);
           }
           readSymbols = 0;
           fprintf(stdout, "\n");
        }
        if(isalnum(*readChar)) {
            if(readSymbols != 0) {
                for(i = 0; i < 80 - writtenChars - readSymbols; i++) {
                    fprintf(stdout, " ");
                }
                for(i = 0; i < readSymbols; i++){
                    fprintf(stdout, "%c", outputBuffer[i]);
                }
                fprintf(stdout, "\n");
                writtenChars = 0;
                readingSymbols = false;
                readSymbols = 0;
            }
            if(!isspace(*readChar) || writtenChars > 0) {
                fprintf(stdout, "%c", *readChar);
                writtenChars++;
            }
        } else if(isspace(*readChar)) {
            if(readingSymbols == false) {
                if(*readChar != '\n'){
                    fprintf(stdout, "%c", *readChar);
                    writtenChars++;
                }
            }
        } else {
            outputBuffer[readSymbols] = *readChar;
            readSymbols++;
            if(readingSymbols == false){
                readingSymbols = true;
            }
        }
    }
    if(readSymbols != 0) {
        for(i = 0; i < 80 - writtenChars - readSymbols; i++) {
            fprintf(stdout, " ");
        }
        for(i = 0; i < readSymbols; i++){
            fprintf(stdout, "%c", outputBuffer[i]);
        }
    }
    fprintf(stdout, "\n");
    fclose(stream);

    return 0;
}
